This repository will contain the rules and decoders for OSSEC.
Rules will be contained in `rules.d` and the decoders in `etc/decoders.d`.
A copy of the combined decoder file may be contained in `etc/`
